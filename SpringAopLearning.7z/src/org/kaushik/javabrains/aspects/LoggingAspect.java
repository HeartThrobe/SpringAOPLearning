package org.kaushik.javabrains.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggingAspect {

	
	@Before(" getAllMethods() && getAllCircleMethods()")
	public void LoggingAdvice(){
		System.out.println("Advice run...get method is called");
	}
	
	
	@Before("execution(* get*(..))") // for all getters and 
	public void LoggingAdvice2(){
		System.out.println("Advice second run...get method is called");
	}
	
	
	
	@Pointcut("execution(* get*(..))") // for all getters and 
	public void getAllMethods(){
		
	}
	
	@Pointcut("within(org.kaushik.javabrains.model.Circle)") // for all getters for Circle
	public void getAllCircleMethods(){}
	
	
	// best practice is to combine the pointcuts logical operation can perform in this
	
	
	//@Pointcut(args()) 
	
	//@Pointcut(target()) 
}
