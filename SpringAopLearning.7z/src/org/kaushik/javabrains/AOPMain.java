package org.kaushik.javabrains;

import org.kaushik.javabrains.model.Circle;
import org.kaushik.javabrains.model.Triangle;
import org.kaushik.javabrains.service.ShapeService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AOPMain {

	public static void main(String[] args) {
		
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("classpath:spring.xml");
		ShapeService object=ctx.getBean("shapeService",ShapeService.class);
		
		Circle cobject=object.getCircle();
		System.out.println(cobject.getName());
		

	
	}

}
